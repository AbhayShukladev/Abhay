<?php
namespace Abhay\CustomerDiscount\Setup\Patch\Data;

use Magento\Customer\Model\Customer;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

class CustomerDiscountPatch implements DataPatchInterface
{
    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * @var CustomerSetupFactory
     */
    private $customerSetupFactory;

    /**
     * CustomerDiscountPatch constructor.
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        CustomerSetupFactory $customerSetupFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->customerSetupFactory = $customerSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function apply()
    {
        $this->moduleDataSetup->startSetup();

        $customerSetup = $this->customerSetupFactory->create(['setup' => $this->moduleDataSetup]);

        $customerSetup->addAttribute(
            Customer::ENTITY,
            'customer_discount',
            [
                'type' => 'decimal',
                'label' => 'Customer Discount',
                'input' => 'text',
                'required' => false,
                'visible' => true,
                'system' => false,
                'position' => 100
            ]
        );

        $customerSetup->addAttribute(
            Customer::ENTITY,
            'discount_type',
            [
                'type' => 'varchar',
                'label' => 'Discount Type',
                'input' => 'select',
                'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Table',
                'option' => ['values' => ['percentage', 'fixed']],
                'required' => false,
                'visible' => true,
                'system' => false,
                'position' => 110
            ]
        );

        $this->moduleDataSetup->endSetup();
    }
}
